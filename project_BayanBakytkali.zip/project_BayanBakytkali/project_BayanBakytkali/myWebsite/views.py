from django.shortcuts import render

def home(request):
    return render(request, 'myWebsite/home.html')

def catalog(request):
    return render(request, 'myWebsite/catalog.html')

def resume(request):
    return render(request, 'myWebsite/resume.html')